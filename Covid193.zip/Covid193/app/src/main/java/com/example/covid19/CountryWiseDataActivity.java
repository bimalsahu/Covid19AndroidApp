package com.example.covid19;

import android.app.Activity;

public class CountryWiseDataActivity extends Activity {
}
