package com.example.covid19;

public class DistrictWiseAdapter {
}
